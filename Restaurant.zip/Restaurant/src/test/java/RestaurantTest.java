import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalTime;

import static org.junit.jupiter.api.Assertions.*;

import org.mockito.*;

//////////////////////////////////////////////////REFACTORED CODE////////////////////////////////////////////////////////

class RestaurantTest {
    Restaurant restaurant;
    //REFACTOR ALL THE REPEATED LINES OF CODE

    //>>>>>>>>>>>>>>>>>>>>>>>>>OPEN/CLOSED<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    //-------FOR THE 2 TESTS BELOW, YOU MAY USE THE CONCEPT OF MOCKING, IF YOU RUN INTO ANY TROUBLE
    LocalTime openingTime, closingTime;
    @Spy
    Restaurant spyRestaurant;

    @BeforeEach
    public void setup(){
        openingTime = LocalTime.parse("10:30:00");
        closingTime = LocalTime.parse("22:00:00");
        restaurant =new Restaurant("Amelie's cafe","Chennai",openingTime,closingTime);
        restaurant.addToMenu("Sweet corn soup",119);
        restaurant.addToMenu("Vegetable lasagne", 269);
    }

    @Test
    public void is_restaurant_open_should_return_true_if_time_is_between_opening_and_closing_time(){
        //WRITE UNIT TEST CASE HERE
        spyRestaurant = Mockito.spy(restaurant);
        Mockito.when(spyRestaurant.getCurrentTime()).thenReturn(LocalTime.parse("13:00:00"));

        Boolean is_restaurant_open = spyRestaurant.isRestaurantOpen();

        assertEquals(true, is_restaurant_open);
    }

    @Test
    public void is_restaurant_open_should_return_false_if_time_is_outside_opening_and_closing_time(){
        //WRITE UNIT TEST CASE HERE
        spyRestaurant = Mockito.spy(restaurant);
        Mockito.when(spyRestaurant.getCurrentTime()).thenReturn(LocalTime.parse("06:00:00"));

        Boolean is_restaurant_open = spyRestaurant.isRestaurantOpen();

        assertEquals(false, is_restaurant_open);
    }

    //<<<<<<<<<<<<<<<<<<<<<<<<<OPEN/CLOSED>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


    //>>>>>>>>>>>>>>>>>>>>>>>>>>>MENU<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    @Test
    public void adding_item_to_menu_should_increase_menu_size_by_1(){
        int initialMenuSize = restaurant.getMenu().size();
        restaurant.addToMenu("Sizzling brownie",319);
        assertEquals(initialMenuSize+1,restaurant.getMenu().size());
    }
    @Test
    public void removing_item_from_menu_should_decrease_menu_size_by_1() throws itemNotFoundException {
        int initialMenuSize = restaurant.getMenu().size();
        restaurant.removeFromMenu("Vegetable lasagne");
        assertEquals(initialMenuSize-1,restaurant.getMenu().size());
    }
    @Test
    public void removing_item_that_does_not_exist_should_throw_exception() {

        assertThrows(itemNotFoundException.class,
                ()->restaurant.removeFromMenu("French fries"));
    }
    //<<<<<<<<<<<<<<<<<<<<<<<MENU>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

    //***********************************************************************************************************************//////////
    //PART 3: ADDING A FEATURE USING TDD
    //Tests for the TDD approach
    //

    //If no items selected, total amount returned must be zero

    //If 3 items are selected, the sume of those 3 items must be returned

    //If the selected items from the menu are sent as arguement
    //the sum of all sent items must be returned

    @Test
    public void total_amount_must_be_0_if_no_items_selected(){
        int total_amount = restaurant.calculateTotalAmount();

        assertEquals(0, total_amount);
    }

    @Test
    public void total_amount_of_3_selected_items_must_be_returned(){
        restaurant.addToMenu("Chips",20);
        restaurant.addToMenu("Cake",100);
        restaurant.addToMenu("Veg Puff",10);

        int total_amount = restaurant.calculateTotalAmount("Chips","Cake","Veg Puff");

        assertEquals(130,total_amount);
    }

    @Test
    public void the_sum_of_items_being_sent_must_be_returned(){

        int total_amount = restaurant.calculateTotalAmount("Sweet corn soup", "Vegetable lasagne");

        assertEquals(388, total_amount);
    }

}